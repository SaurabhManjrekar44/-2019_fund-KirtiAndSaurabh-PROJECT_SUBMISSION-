package fr.epita.datamodel;

public class MCQAnswer {
	
	private MCQChoice choice;
	
	private Student student;

	/**
	 * @return choice: get the answer chosen by student
	 */
	public MCQChoice getChoice() {
		return choice;
	}

	/**
	 * @param choice: set the Answer chosen by student
	 */
	public void setChoice(MCQChoice choice) {
		this.choice = choice;
	}

	/**
	 * @return student : Student undertaking exam
	 */
	public Student getStudent() {
		return student;
	}

	/**
	 * @param student : Set the student undertaking exam
	 */
	public void setStudent(Student student) {
		this.student = student;
	}

}
