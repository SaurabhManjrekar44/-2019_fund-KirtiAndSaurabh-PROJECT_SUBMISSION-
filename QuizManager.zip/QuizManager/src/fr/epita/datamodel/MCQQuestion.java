package fr.epita.datamodel;

public class MCQQuestion extends Question {

}
