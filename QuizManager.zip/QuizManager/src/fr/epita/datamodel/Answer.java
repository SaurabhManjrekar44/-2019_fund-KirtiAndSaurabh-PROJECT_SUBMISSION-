package fr.epita.datamodel;

public class Answer {

	private String text;
	
	private Question question;

	/**
	 * @return Answer text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text: sets the text in object
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return Question Object
	 */
	public Question getQuestion() {
		return question;
	}

	/**
	 * @param question : set question object
	 */
	public void setQuestion(Question question) {
		this.question = question;
	}
	
	
}
