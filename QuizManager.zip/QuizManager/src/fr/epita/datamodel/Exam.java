package fr.epita.datamodel;

import java.util.List;

public class Exam {

	private long grade;
	
	private List<Answer> listAnswers;
	
	private List<MCQAnswer> listMCQAnswers;

	/**
	 * @return the grade
	 */
	public long getGrade() {
		return grade;
	}

	/**
	 * @param grade the grade to set
	 */
	public void setGrade(long grade) {
		this.grade = grade;
	}

	/**
	 * @return the listAnswers
	 */
	public List<Answer> getListAnswers() {
		return listAnswers;
	}

	/**
	 * @param listAnswers the listAnswers to set
	 */
	public void setListAnswers(List<Answer> listAnswers) {
		this.listAnswers = listAnswers;
	}

	/**
	 * @return the listMCQAnswers
	 */
	public List<MCQAnswer> getListMCQAnswers() {
		return listMCQAnswers;
	}

	/**
	 * @param listMCQAnswers the listMCQAnswers to set
	 */
	public void setListMCQAnswers(List<MCQAnswer> listMCQAnswers) {
		this.listMCQAnswers = listMCQAnswers;
	}

	
}
