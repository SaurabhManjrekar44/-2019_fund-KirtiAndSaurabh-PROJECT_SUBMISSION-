package fr.epita.quiz.manager;


public class QuizMain {
	private static String loginTypeInput = "please select the login type\n 1 -> Teacher\n 2 -> Studentt";
	private static String operationInput = "What do you want to do ?\n 1 -> Create/Update/Delete/Search question\n 2 -> Generate quiz question based on topic";
	public static void main(String[] args) {
		QuizManager quizManazer = new QuizManager();
		//taking input for login type
		String authentication=quizManazer.login();
		if(authentication.equalsIgnoreCase("Student") ) {
			
			System.out.println("\n--------------------------Quiz Selection---------------------------");
			quizManazer.takeQuiz();
		
		}
		else if(authentication.equalsIgnoreCase("Teacher")) {
				int selection1 = quizManazer.inputIntegerFromUser (operationInput);
				switch (selection1) {
					case 1 : quizManazer.performCURDOperation();break;
					case 2 : quizManazer.createQuiz();break;
					default : System.out.println("invalid selection");
			}
		}
		else {
			System.out.print("Incorrect credentials");
		}
	}
}
