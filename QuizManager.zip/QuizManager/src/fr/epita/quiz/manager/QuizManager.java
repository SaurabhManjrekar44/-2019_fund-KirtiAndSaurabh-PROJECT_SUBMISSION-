/**
 * 
 */
package fr.epita.quiz.manager;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.h2.util.StringUtils;

import fr.epita.datamodel.Answer;
import fr.epita.datamodel.MCQChoice;
import fr.epita.datamodel.MCQQuestion;
import fr.epita.datamodel.Question;
import fr.epita.datamodel.Quiz;
import fr.epita.services.dao.QuestionJDBCDAO;

/**
 * QuizManager is used to perform CRUD operations
 * 
 * @author ksingh
 *
 */
public class QuizManager {
	QuestionJDBCDAO db = new QuestionJDBCDAO();
	int howManyChoice = 4;

	/**
	 * @param input : contains the message to display to the user while asking for
	 *              String Input
	 * @return str: String input from console
	 */
	public String inputStringFromUser(String input) {
		System.out.println("\n" + input + "\n");
		Scanner scanner = new Scanner(System.in);
		String str = scanner.nextLine();
		if (StringUtils.isNullOrEmpty(str)) {
			str = inputStringFromUser("Oo Oh: input is wrong, please provide the right input\n");
		}
		return str;
	}

	/**
	 * @param input : contains the message to display to the user while asking for
	 *              Integer Input
	 * @return val: Integer input from console
	 */
	public int inputIntegerFromUser(String input) {
		System.out.println("\n" + input + "\n");
		Scanner scanner = new Scanner(System.in);
		String intValue = scanner.nextLine();
		int val;
		try {
			val = Integer.parseInt(intValue);
		} catch (NumberFormatException e) {
			val = inputIntegerFromUser("Oo Oh: input is wrong, please provide the right input\n");
		}

		return val;
	}

	/**
	 * Method is used to take value from user to set setValid column from user for
	 * MCQAnswer Table. Ensuring the return value is a boolean for future
	 * Comparison and scoring.
	 * 
	 * @param input is displaying message to the user
	 * @return inputBooleanFromUser : is used to setValid Flag in Table MCQAnswer
	 */
	public boolean inputBooleanFromUser(String input) {
		System.out.println("\n" + input + "\n");
		Scanner scanner = new Scanner(System.in);
		String booleanValue = scanner.nextLine();
		if ("T".equalsIgnoreCase(booleanValue)) {
			return Boolean.TRUE;
		} else if ("F".equalsIgnoreCase(booleanValue)) {
			return Boolean.FALSE;
		}
		return inputBooleanFromUser("Oo Oh: input is wrong, please provide the right input\n");
	}

	/**
	 * This method is used to Create Quiz based on Topics entered by Teacher. 
	 * we are taking Topics from the user and displaying all the questions with associated with this Topic on console.
	 * Taking Title for this new Quiz.
	 * Saving the questionIds of all the questions displayed on console in the form of string.
	 * Creating Quiz with user entered Title, list of topics, and unique Quiz Id
	 */
	public void createQuiz() {
		String choice = "N";
		do {
			System.out.println("\nLets find the questions you want to update in the Quiz");
			HashMap<Question, ArrayList<MCQChoice>> displaySerchedQuestionOnTopic = displaySerchedQuestionOnTopic();
			Set<Question> questions = displaySerchedQuestionOnTopic.keySet();
			Quiz newQuiz = new Quiz();
			String quizTitle = inputStringFromUser("Enter the Title of the Quiz");
			newQuiz.setTitle(quizTitle);
			String questionIds = "";
			int i = 1;
			for (Question question2 : questions) {
				questionIds = questionIds + question2.getId();
				if (i != questions.size()) {
					questionIds = questionIds + ",";
				}
				i++;
			}
			newQuiz.setQuestionIds(questionIds);

			db.createQuiz(newQuiz);
			System.out.println("Quiz with title " + quizTitle + " created successfully");
			String choiseText = inputStringFromUser("Do you want to generate Text File for this Quiz ? Enter: Y/N");
			if ("Y".equalsIgnoreCase(choiseText)) {
				createQuizTextFile(displaySerchedQuestionOnTopic, quizTitle);
			}
			choice = inputStringFromUser("Do you want to create another Quiz? : Enter Y/N");
		} while (choice.equalsIgnoreCase("Y"));

	}

	/**
	 * This method is used to implement the feature where students selects quiz and gets the final score
	 * we display all available Quiz along with Title and ID, Students can select Quiz and provide their answer to move to next Question.
	 * takeQuizForQuestions is called
	 */
	public void takeQuiz() {
		String takeQuiz = inputStringFromUser("Do you want to take quiz? Enter : Y/N\n");
		if ("Y".equalsIgnoreCase(takeQuiz)) {
			System.out.println("We have following different quiz\n");
			List<Quiz> searchQuiz = db.searchQuiz();

			HashMap<Integer, String> quizIdQuestionMap = new HashMap<Integer, String>();
			for (Quiz quiz : searchQuiz) {
				System.out.println("Quiz ID: " + quiz.getId() + " Quiz Title : " + quiz.getTitle());
				quizIdQuestionMap.put(quiz.getId(), quiz.getQuestionIds());
			}
			int quizId = inputIntegerFromUser("Provide the quiz ID you want to take?");

			String questionsToShow = quizIdQuestionMap.get(quizId);
			System.out.println("Quiz started, to go to the next question please enter your choice");
			takeQuizForQuestions(questionsToShow);
		}

	}

	/**
	 * @param displaySerchedQuestionOnTopic: we take the list of all the questions in a Quiz along with answer in this HashMap
	 * @param quizTitle : we are getting the Quiz title and using it to create the name of text file.
	 */
	public void createQuizTextFile(HashMap<Question, ArrayList<MCQChoice>> displaySerchedQuestionOnTopic, String quizTitle) {
		PrintWriter writer;
		String fileName = "D:\\" + quizTitle + ".txt";
		try {
			writer = new PrintWriter(fileName, "UTF-8");
			int questionNumber = 1;
			for (Question question : displaySerchedQuestionOnTopic.keySet()) {
				writer.println("Q" + questionNumber + " : " + question.getQuestion());
				writer.println();
				questionNumber++;
				// checking if question is MCQ question by checking if it has MCQ choices
				if (displaySerchedQuestionOnTopic.get(question) != null
						&& displaySerchedQuestionOnTopic.get(question).size() > 0) {
					// searchQuestionBasedOnQuestion.get(question) = Value of map, which is list of
					// choice for the given question
					int choiceNumber = 1;
					for (MCQChoice choice : displaySerchedQuestionOnTopic.get(question)) {
						// printing choice label
						writer.println(choiceNumber + ": " + choice.getLabel());
						choiceNumber++;
					}
				}
				writer.println();
				writer.println();
			}
			writer.close();
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(fileName + " created successfully");
	}

	/**
	 * This Function is used to give Menu for CRUD Functions to User 
	 * 
	 */
	public void performCURDOperation() {
		String teacherOptions = "\nWhich operation would you like to perform\n 1: Create Question\n 2: Update question\n 3: Delete a question\n 4: Search a question based on topic\n";
		int ops = inputIntegerFromUser(teacherOptions);
		switch (ops) {
		case 1:
			createQuestion();
			break;
		case 2:
			updateQuestion();
			break;
		case 3:
			deleteQuestion();
			break;
		case 4:
			String ans;
			do {
				displaySerchedQuestionOnTopic();
				ans = inputStringFromUser("do you want to continue search? Y/N");
			} while (ans.equalsIgnoreCase("Y"));
			break;
		default:
			System.out.println("invalid option");
		}
	}

	/**
	 * we are updating an existing question in DB based based on question ID provided by user after topic based search
	 * db.update function is called 
	 */
	public void updateQuestion() {
		String choice = "Y";
		do {
			System.out.println("\nLets find the question you want to update");
			displaySerchedQuestionOnTopic();
			Question question = new Question();
			int questionId = inputIntegerFromUser("Please input the ID of question you want to edit");
			question.setId(questionId);
			String newQuestion = inputStringFromUser("Write new question to replace old one, eaxmple: What 2*2?");
			question.setQuestion(newQuestion);
			int newDifficulty = inputIntegerFromUser("What is the new difficulty level from 1 to 5?");
			question.setDifficulty(newDifficulty);
			db.update(question);
			System.out.println("\nUPDATE SUCCESSFUL");
			choice = inputStringFromUser("Do you want to update another Question? : Enter Y/N");
		} while (choice.equalsIgnoreCase("Y"));

	}

	/**
	 * we are deleting question on the basis of Question ID, User can look for Question Id from the list of questions on the basis of topic.
	 * displaySerchedQuestionOnTopic() is used to display the list of question on the basis of topic.
	 */
	public void deleteQuestion() {
		String choice = "Y";
		do {
			System.out.println("\nLets find the question you want to Delete");
			displaySerchedQuestionOnTopic();
			Question question = new Question();
			int questionId = inputIntegerFromUser("Please input the ID of question you want to Delete");
			question.setId(questionId);
			db.delete(question);
			System.out.println("\nDELETE SUCCESSFUL");
			choice = inputStringFromUser("Do you want to delete another Question? : Enter Y/N");
		} while (choice.equalsIgnoreCase("Y"));

	}

	/**
	 * Menu for Creating Question(Adding new Questions) with 2 choices : 1: Open questions\n 2: MCQ questions
	 */
	public void createQuestion() {
		String choice = "N";
		do {
			String createQuestionOption = "Which type of question do you want to create\n 1: Open questions\n 2: MCQ questions\n";
			int ops = inputIntegerFromUser(createQuestionOption);
			switch (ops) {
			case 1:
				createOpenQuestion();
				break;
			case 2:
				createMcqQuestion();
				break;
			default:
				System.out.println("invalid option");
			}
			System.out.println("\nQuestion is created successfully");
			choice = inputStringFromUser("Do you want to create another Question? : Enter Y/N");
		} while (choice.equalsIgnoreCase("Y"));
	}

	/**
	 * Creating Open Question where Question is plain text and setting answer and Topic
	 * associating answer and Topic with questions on the basis of Question Id
	 * calling Function db.create and db.createAnswer.
	 */
	public void createOpenQuestion() {
		Question question = new Question();
		question.setId(1);// no need of this, not using anywhere
		String qsn = inputStringFromUser("Write a question, eaxmple: What 2*2?");
		question.setQuestion(qsn);
		int difficulty = inputIntegerFromUser("What is the difficulty level from 1 to 5?");
		question.setDifficulty(difficulty);
		String topics = inputStringFromUser("What are the topics, eaxmple: Math,Algebra");
		question.setTopics(topics.split(","));
		String answertext = inputStringFromUser("What is the Answer for this open Question");

		int questionId = db.create(question);
		question.setId(questionId);

		System.out.println(question.toString());
		Answer answer = new Answer();
		answer.setText(answertext);
		answer.setQuestion(question);
		db.createAnswer(answer);

	
	}

	
	/**
	 * Creating MCQ Question where Question is plain text and setting Choices and Topics
	 * setValid is called to set boolean value for correct/incorrect MCQ choice  
	 * Associating MCQ choice and Topics with questions on the basis of Question Id
	 * Calling Function db.create and db.createAnswer
	 */
	public void createMcqQuestion() {

		MCQQuestion question = new MCQQuestion();
		question.setId(1);// no need of this
		String qsn = inputStringFromUser("Write a question, eaxmple: What 2*2?");
		question.setQuestion(qsn);
		int difficulty = inputIntegerFromUser("What is the deifficulty level from 1 to 5?");
		question.setDifficulty(difficulty);
		String topics = inputStringFromUser("What are the topics, eaxmple: Math,Algebra");
		question.setTopics(topics.split(","));
		System.out.println(question.toString());
		// creaing the question and setting the generated question id
		question.setId(db.create(question));
		System.out.println("Provide Data for your MCQ choice");
		for (int i = 1; i <= howManyChoice; i++) {
			MCQChoice mcqChoice = new MCQChoice();
			mcqChoice.setId(1);// no need of this
			mcqChoice.setLabel(inputStringFromUser("Option" + i + ": "));
			mcqChoice.setQuestion(question);
			db.createChoice(mcqChoice);
			mcqChoice.setValid(
					inputBooleanFromUser("Is this option valid/correct for this question? Input should be: T/F \n"));
		}
	}

	/**
	 * 
	 * public void displaySerchedQuestion () { //take search string from user String
	 * ques = inputStringFromUser("Type a question, eaxmple: What 2*2? or 2*2");
	 * //calling function to find matching questions and its choices and storing it
	 * in hashmap HashMap<Question, ArrayList<MCQChoice>>
	 * searchQuestionBasedOnQuestion = searchQuestionBasedOnQuestion(ques);
	 * //searchQuestionBasedOnQuestion.keySet() = in this map Question is key, this
	 * key set has all the questions with matching criteria, here we are iterating
	 * them one by one for (Question
	 * question:searchQuestionBasedOnQuestion.keySet()) { // printing the question
	 * one by one System.out.println("ID: " + question.getId() + " Question: "+
	 * question.getQuestion()); //printing difficulty level one by one
	 * System.out.println("Difficulty: " + question.getDifficulty()); //checking if
	 * question is MCQ question by checking if it has MCQ choices if
	 * (searchQuestionBasedOnQuestion.get(question) != null &&
	 * searchQuestionBasedOnQuestion.get(question).size() > 0) {
	 * System.out.println("Select correct answer"); //
	 * searchQuestionBasedOnQuestion.get(question) = Value of map, which is list of
	 * choice for the given question int choiceNumber = 1; for (MCQChoice choice :
	 * searchQuestionBasedOnQuestion.get(question)) { //printing choice label
	 * System.out.println(choiceNumber +": "+ choice.getLabel()); choiceNumber++; }
	 * System.out.println(); } else { // question is open question Answer ans =
	 * searchAnswerForQuestion(question); if
	 * (!StringUtils.isNullOrEmpty(ans.getText())) System.out.println("Answer: " +
	 * ans.getText());
	 * 
	 * } } }
	 */

	/**
	 * Displays all the questions searched on the basis of Topic
	 * @return searchQuestionResultBasedOnTopic  : returns questions associated with the user entered Topics 
	 * searchQuestionResultBasedOnTopic<Question, ArrayList<MCQChoice>is HashMap with QUestion object as key and MCQ Choice list as Value (for the associated Question ID stored in key)
	 */
	public HashMap<Question, ArrayList<MCQChoice>> displaySerchedQuestionOnTopic() {
		// take search string from user
		String topic = inputStringFromUser("Provide the topic for Question search, eaxmple: Java,Math");
		String[] topics = topic.split(",");
		HashMap<Question, ArrayList<MCQChoice>> searchQuestionResultBasedOnTopic = new HashMap<Question, ArrayList<MCQChoice>>();
		for (String string : topics) {
			searchQuestionResultBasedOnTopic.putAll(searchQuestionBasedOnTopic(string));
		}
		// searchQuestionBasedOnTopic.keySet() = in this map Question is key, this key set has all the questions 
		for (Question question : searchQuestionResultBasedOnTopic.keySet()) {
			// printing the question one by one
			System.out.println("\nID: " + question.getId() + " Question: " + question.getQuestion());
			// printing difficulty level one by one
			System.out.println("Difficulty: " + question.getDifficulty());
			// checking if question is MCQ question by checking if it has MCQ choices
			if (searchQuestionResultBasedOnTopic.get(question) != null
					&& searchQuestionResultBasedOnTopic.get(question).size() > 0) {

				// searchQuestionBasedOnQuestion.get(question) = Value of map, which is list of choice for the given question
				int choiceNumber = 1;
				for (MCQChoice choice : searchQuestionResultBasedOnTopic.get(question)) {
					String correctAnswer = "";
					if (choice.isValid()) {
						correctAnswer = correctAnswer + "   (Correct Answer)";
					}
					// printing choice label
					System.out.println(choiceNumber + ": " + choice.getLabel() + correctAnswer);
					choiceNumber++;
				}
				System.out.println();
			} else {
				// question is open question
				Answer ans = searchAnswerForQuestion(question);
				if (!StringUtils.isNullOrEmpty(ans.getText()))
					System.out.println("Answer: " + ans.getText());

			}

		}
		return searchQuestionResultBasedOnTopic;
	}

	/**
	 * 
	 * public HashMap<Question, ArrayList<MCQChoice>>
	 * searchQuestionBasedOnQuestion(String question){ // creating object of Hashmap
	 * where key is question object and value is list choices of that question
	 * HashMap<Question, ArrayList<MCQChoice>> questionsAndChoicesMap = new
	 * HashMap<Question, ArrayList<MCQChoice>>(); // searching all the questions to
	 * look for a match with provided string value List<Question>
	 * searchQuestionFromQuestion = db.searchQuestionFromQuestion(question);
	 * //checking one by one if the searched questions have any choices listed(in
	 * case it is MCQQuestion) for (Question question2 : searchQuestionFromQuestion)
	 * { //searchChoicesForQuestion(question2) = searching for MCQ choices for a
	 * question by calling method //after choices are found adding the list of
	 * choices to the map questionsAndChoicesMap.put(question2,
	 * searchChoicesForQuestion(question2)); } // returing the hashmap return
	 * questionsAndChoicesMap; }
	 */

	/**
	 * Searches Questions and associated choices based on Topic name from user
	 * @param topic : String of all the topicsfrom user
	 * @return questionsAndChoicesMap : Hashmap where key is question object and value is list of choices of that question
	 */
	public HashMap<Question, ArrayList<MCQChoice>> searchQuestionBasedOnTopic(String topic) {
		// creating object of Hashmap where key is question object and value is list of choices of that question
		HashMap<Question, ArrayList<MCQChoice>> questionsAndChoicesMap = new HashMap<Question, ArrayList<MCQChoice>>();
		// searching all the questions to look for a match with provided string value
		List<Question> searchQuestionFromQuestion = db.searchQuestionFromTopic(topic);
		// checking one by one if the searched questions have any choices listed(in case
		// it is MCQQuestion)
		for (Question question2 : searchQuestionFromQuestion) {
			// searchChoicesForQuestion(question2) = searching for MCQ choices for a
			// question by calling method
			// after choices are found adding the list of choices to the map
			questionsAndChoicesMap.put(question2, searchChoicesForQuestion(question2));
		}
		// returing the hashmap
		return questionsAndChoicesMap;
	}

	/**
	 * Searching for MCQ choices for questions
	 * @param question : Object of Question
	 * @return ArrayList<MCQChoice> getting ArrayList with all the MCQchoces for given Question from method db.searchChoicesFromQuestionId
	 */
	public ArrayList<MCQChoice> searchChoicesForQuestion(Question question) {
		// search for choices based on question ID
		return (ArrayList<MCQChoice>) db.searchChoicesFromQuestionId(question.getId());
	}


	/**
	 * @param question : Object of Question
	 * @return Answer Returns object of Answer class
	 * searchAnswerFromQuestionId : getting answer object which has answer text along with Question Object for given Question from method db.searchAnswerFromQuestionId
	 */
	public Answer searchAnswerForQuestion(Question question) {
		// search for choices based on question ID
		return db.searchAnswerFromQuestionId(question.getId());
	}

	/**
	 * Displays Question one by one, It takes the answer from user and compares it with saved answer
	 * totalCorrectAnswer is to count total correct answers in this quiz, 
	 * @param questionId : Displays the questions to the user during Quiz using this QuestioId String
	 */
	public void takeQuizForQuestions(String questionId) {
		String[] qIds = questionId.split(",");
		int i = 1;
		int totalCorrectAnswer = 0;
		for (String id : qIds) {
			int idInt = Integer.parseInt(id);
			Question ques = db.searchQuestionFromId(idInt);
			ArrayList<MCQChoice> choices = searchChoicesForQuestion(ques);
			Answer answer = searchAnswerForQuestion(ques);
			System.out.println("Q" + i + " " + ques.getQuestion());
			i++;
			int j = 1;
			int correctChoice = 0;
			if (!StringUtils.isNullOrEmpty(answer.getText())) {
				String userChoice = inputStringFromUser("Your Answer:");
				if (answer.getText().equalsIgnoreCase(userChoice)) {
					totalCorrectAnswer++;
				}
			} else if (!choices.isEmpty()) {
				for (MCQChoice choice : choices) {
					System.out.println();
					System.out.println(j + ": " + choice.getLabel());
					if (choice.isValid()) {
						correctChoice = j;
					}
					j++;
				}
				int userChoice = inputIntegerFromUser("Your Answer:");
				if (correctChoice == userChoice) {
					totalCorrectAnswer++;
				}
			}

		}

		System.out.println("\nQuiz completed. Your score is " + totalCorrectAnswer + " out of " + qIds.length);
	}

	// function to authenticate login of Student and Password
	
	public String login() {
		System.out.println("---------------------------Welcome to Sokratis---------------------------");
		String name = inputStringFromUser("Enter User Name:");
		String password = inputStringFromUser("Enter Password");
		String loginSuccess = db.loginAuthentication(name, password);
		return loginSuccess;
	}
}
