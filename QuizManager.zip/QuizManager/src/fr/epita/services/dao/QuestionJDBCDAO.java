package fr.epita.services.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.epita.datamodel.Answer;
import fr.epita.datamodel.MCQChoice;
import fr.epita.datamodel.Question;
import fr.epita.datamodel.Quiz;
import fr.epita.services.Configuration;

public class QuestionJDBCDAO {
	private  String LOGIN_QUERY = "SELECT * FROM LOGIN1 WHERE (? IS NOT NULL AND USERID=?)  AND (? IS NOT NULL AND PASSWORD=?)";
	private  String INSERT_QUESTION_QUERY = "INSERT INTO QUESTION (QUESTION,DIFFICULTY) VALUES (?, ?)";
	private  String INSERT_TOPIC_QUERY = "INSERT INTO TOPICS (ID,TOPIC) VALUES (?, ?)";
	private  String INSERT_CHOICE_QUERY = "INSERT INTO CHOICE (question_id,valid,label) VALUES (?, ?, ?)";
	private  String INSERT_ANSWER_QUERY = "INSERT INTO ANSWERS (question_id,answer_text) VALUES (?, ?)";
	private  String INSERT_QUIZ_QUERY = "INSERT INTO QUIZ (question_id,Title) VALUES (?, ?)";
	private  String UPDATE_QUERY = "UPDATE QUESTION SET QUESTION=?,DIFFICULTY=? WHERE ID=?";
	private  String DELETE_QUESTION_QUERY = "DELETE QUESTION WHERE ID=?";
	private  String DELETE_TOPIC_QUERY = "DELETE TOPICS WHERE ID=?";
	private  String DELETE_ANSWER_QUERY = "DELETE ANSWERS WHERE QUESTION_ID=?";
	private  String DELETE_MCQCHOICE_QUERY = "DELETE CHOICE WHERE QUESTION_ID=?";
	//private  String SEARCH_QUERY = "SELECT QUESTION,ID,DIFFICULTY FROM QUESTIONS WHERE (? IS NOT NULL AND QUESTION LIKE ?) AND (? IS NOT NULL  AND DIFFICULTY = ?)";
	//private  String SEARCH_QUESTION_FROM_QUESTION_QUERY = "SELECT * from question where question like ?";
	private  String SEARCH_QUIZ = "SELECT quiz_id, QUESTION_ID, TITLE from quiz";
	private  String SEARCH_QUESTION_FROM_TOPIC_QUERY = "select Q.ID, Q.QUESTION,Q.DIFFICULTY from  question Q,TOPICs T WHERE Upper(T.TOPIC) LIKE upper(?) AND Q.ID=T.ID";
	private  String SEARCH_CHOICES_FROM_QUESTION_ID_QUERY = "SELECT * from choice where question_id= ?";
	private  String SEARCH_ANSWER_FROM_QUESTION_ID_QUERY = "SELECT answer_text from answers where question_id= ?";
	private  String SEARCH_QUESTION_FROM_QUESTION_ID_QUERY = "SELECT * from question where id= ?";
	
	
	/**
	 * Inserting in Question Table and Topics Table
	 * Inserting new Question in the Database and assigning a Unique question ID 
	 * Inserting Topics in Topic Table for each Question Id.
	 * @param question : Question Object
	 * @return Id : This is Unique question Id created in the Database 
	 */
	public int create(Question question) {
		int id=0;
		PreparedStatement stmt;
		try {
			Connection connection = getConnection();
			stmt = connection
					.prepareStatement(INSERT_QUESTION_QUERY,Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.executeUpdate();
			ResultSet keys = stmt.getGeneratedKeys();
			keys.next();
			id = keys.getInt(1);
			stmt.close();
			
			//insert topics
			String [] topics = question.getTopics();
			if (topics != null && topics.length > 0) {
				for (String topic : topics) {
					stmt = connection.prepareStatement(INSERT_TOPIC_QUERY,Statement.RETURN_GENERATED_KEYS);
					stmt.setInt(1, id);
					stmt.setString(2, topic);
					stmt.execute();
					stmt.close();
				}
			}
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
		
	}
	
	public void update(Question question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection.prepareStatement(UPDATE_QUERY);
			stmt.setString(1, question.getQuestion());
			stmt.setInt(2, question.getDifficulty());
			stmt.setInt(3, question.getId());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void createQuiz(Quiz newQuiz) {
		PreparedStatement stmt;
		try {
			Connection connection = getConnection();
			stmt = connection
					.prepareStatement(INSERT_QUIZ_QUERY);
			stmt.setString(1, newQuiz.getQuestionIds());
			stmt.setString(2, newQuiz.getTitle());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * we are pulling list of all the available quiz in the Table Quiz.
	 * @return listOfQuiz gives list of all available Quiz in QUIZ Table
	 */
	public List<Quiz> searchQuiz() {
		List<Quiz> listOfQuiz = new ArrayList<Quiz>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUIZ);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String questionIds = rs.getString(2);
				String title = rs.getString(3);
				Quiz quiz = new Quiz();
				quiz.setQuestionIds(questionIds);
				quiz.setTitle(title);
				quiz.setId(id);
				listOfQuiz.add(quiz);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listOfQuiz;
	}
		
	
	/**
	 * Deleting question , its associated topics, Answers/MCQAnswers
	 * @param question taking Question object as per user choice
	 */
	public void delete(Question question) {
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection.prepareStatement(DELETE_TOPIC_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			stmt = connection.prepareStatement(DELETE_ANSWER_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			stmt = connection.prepareStatement(DELETE_MCQCHOICE_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			stmt = connection.prepareStatement(DELETE_QUESTION_QUERY);
			stmt.setInt(1, question.getId());
			
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * to search Query 
	 * @param question takes Question object for search
	 * @return List<Question> this returns list of questions on the basis of Topic 
	 
	public List<Question> search(Question question) {
		List<Question> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUERY);
			stmt.setString(1, question.getQuestion());
			stmt.setString(2, "%" + question.getQuestion()+ "%");
			stmt.setInt(3, question.getDifficulty());
			stmt.setInt(4, question.getDifficulty());
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String questionLabel = rs.getString(1);
				int id = rs.getInt(2);
				int difficulty = rs.getInt(3);
				Question currentQuestion = new Question();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				questions.add(currentQuestion);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;
	}
	
	public List<Question> searchQuestionFromQuestion(String question) {
		List<Question> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUESTION_FROM_QUESTION_QUERY);
			stmt.setString(1, "%" + question+ "%");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String questionLabel = rs.getString(2);
				int difficulty = rs.getInt(3);
				Question currentQuestion = new Question();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				questions.add(currentQuestion);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;
	}
	*/
	
	/**
	 * To search Question on the basis of Topic
	 * @param topic takes Question object for search
	 * @return List<Question> this returns list of questions on the basis of Topic 
	 */
	public List<Question> searchQuestionFromTopic(String topic) {
		List<Question> questions = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUESTION_FROM_TOPIC_QUERY);
			stmt.setString(1, "%" + topic+ "%");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String questionLabel = rs.getString(2);
				int difficulty = rs.getInt(3);
				Question currentQuestion = new Question();
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
				questions.add(currentQuestion);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;
	}
	
	/**
	 * @param questionId : search questions from Question Table on the basis of QuestionId
	 * @return Question object
	 */
	public Question searchQuestionFromId(int questionId) {
		Question currentQuestion = new Question();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_QUESTION_FROM_QUESTION_ID_QUERY);
			stmt.setInt(1, questionId);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String questionLabel = rs.getString(2);
				int difficulty = rs.getInt(3);
				
				currentQuestion.setId(id);
				currentQuestion.setQuestion(questionLabel);
				currentQuestion.setDifficulty(difficulty);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return currentQuestion;
	}
	
	/**
	 * search MCQ choices from Choice Table associated with the provided QuestionId
	 * @param questionId : QuestionId of a given Question
	 * @return List<MCQChoice>: List of MCQ choices associated with the questionId
	 */
	public List<MCQChoice> searchChoicesFromQuestionId(int questionId) {
		List<MCQChoice> choices = new ArrayList<>();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_CHOICES_FROM_QUESTION_ID_QUERY);
			stmt.setInt(1, questionId);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				int choice_id = rs.getInt(1);
				boolean isValid = rs.getBoolean(3);
				String label = rs.getString(4);
				MCQChoice choice = new MCQChoice();
				choice.setId(choice_id);
				choice.setValid(isValid);
				choice.setLabel(label);
				choices.add(choice);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return choices;
	}
	
	/**
	 *  search Answer from Answer Table associated with the provided QuestionId
	 * @param questionId : QuestionId of a given Question
	 * @return Answer object with answers associated with the questionId
	 */
	public Answer searchAnswerFromQuestionId(int questionId) {
		Answer ans = new Answer();
		try {
			Connection connection = getConnection();
			PreparedStatement stmt = connection
					.prepareStatement(SEARCH_ANSWER_FROM_QUESTION_ID_QUERY);
			stmt.setInt(1, questionId);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String answerText = rs.getString(1);
				ans.setText(answerText);
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ans;
	}
	
	/**
	 * Insert text in Choice Table for creating multiples choices for MCQ Questions, these would be associated with a question Id
	 * @param mcqChoice: Object of MCQChoice table
	 */
	public void createChoice(MCQChoice mcqChoice) {
		PreparedStatement stmt;
		try {
			Connection connection = getConnection();
			stmt = connection.prepareStatement(INSERT_CHOICE_QUERY);
			stmt.setInt(1, mcqChoice.getQuestion().getId());
			stmt.setBoolean(2, mcqChoice.isValid());
			stmt.setString(3, mcqChoice.getLabel());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Insert Answers in Table Answer 
	 * @param answer : Object of Answer class
	 */
	public void createAnswer(Answer answer) {
		PreparedStatement stmt;
		try {
			Connection connection = getConnection();
			stmt = connection.prepareStatement(INSERT_ANSWER_QUERY);
			stmt.setInt(1, answer.getQuestion().getId());
			stmt.setString(2, answer.getText());
			stmt.execute();
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private Connection getConnection() throws SQLException, FileNotFoundException, IOException {
		Configuration config = Configuration.getInstance();
		String url = config.getPropertyValue("jdbc.url");
		String username = config.getPropertyValue("jdbc.username");
		String password = config.getPropertyValue("jdbc.password");
		
		return DriverManager.getConnection(url, username, password);
	}
	
	/**
	 * Verifying the user by login, either as Student or as Teacher
	 * @param name : Name of User
	 * @param password : Password for User
	 * @return 
	 */
	public String loginAuthentication(String name,String password) {
		String loginSuccess="Incorrect";
		PreparedStatement stmt;
		
		try {
		            // Create SQL Query
		    
			Connection connection = getConnection();
			stmt = connection.prepareStatement(LOGIN_QUERY);
			stmt.setString(1, name);
			stmt.setString(2, name);
			stmt.setString(3, password);
			stmt.setString(4, password);
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				loginSuccess= rs.getString("TYPE");
				//loginSuccess="success";
			}
			stmt.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//System.out.println(loginSuccess);
		return loginSuccess;
		
	}

}
