--Login Data/User Creation
INSERT INTO LOGIN1 VALUES('Saurabh', '1111','Student');
INSERT INTO LOGIN1 VALUES('Kirti', '1111','Teacher');

--math question
INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (100, 'How many digits are there in Hindu-Arabic System?', 4);
INSERT into topics (id, TOPIC) values (100, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (100,true, '10');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (100,false, '20');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (100,false, '30');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (100,false, '40');


INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (101, 'Among the following which natural number has no predecessor?', 4);
INSERT into topics (id, TOPIC) values (101, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (101,false, '100');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (101,false, '200');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (101,true, '1');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (101,false, '0');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (102, 'Which among the following is the largest known number in the world?', 4);
INSERT into topics (id, TOPIC) values (102, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (102,false, 'infinity');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (102,false, 'googol');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (102,true, 'googolplex');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (102,false, 'gram');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (103, 'The average of first 50 natural numbers is?', 4);
INSERT into topics (id, TOPIC) values (103, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (103,false, '25.35');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (103,true, '25.5');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (103,false, '25.00');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (103,false, '12.25');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (104, 'The number of 3-digit numbers divisible by 6, is?', 2);
INSERT into topics (id, TOPIC) values (104, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (104,false, '149');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (104,false, '166');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (104,true, '150');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (104,false, '151');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (105, 'What is 1004 divided by 2?', 2);
INSERT into topics (id, TOPIC) values (105, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (105,false, '52');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (105,true, '502');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (105,false, '520');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (105,false, '5002');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (106, 'A clock strikes once at 1 o’clock, twice at 2 o’clock, thrice at 3 o’clock and so on. How many times will it strike in 24 hours?', 5);
INSERT into topics (id, TOPIC) values (106, 'MATH');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (106,false, '78');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (106,false, '136');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (106,true, '156');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (106,false, '196');


INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (107, 'In which civilization dot patterns were first employed to represent numbers?', 4);
INSERT into topics (id, TOPIC) values (107, 'MATH');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (107, 'Chinese');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (108, 'In which numerals X, M, V, L, etc. belong to?', 2);
INSERT into topics (id, TOPIC) values (108, 'MATH');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (108, 'Roman');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (109, 'Who wrote an elaborate history of Greek geometry from its earliest origins?', 3);
INSERT into topics (id, TOPIC) values (109, 'MATH');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (109, 'Eudemus');


--JAVA Questions

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (200, 'What is a class in java?', 2);
INSERT into topics (id, TOPIC) values (200, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (200,true, 'A class is a blue print from which individual objects are created. A class can contain fields and methods to describe the behavior of an object.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (200,false, 'class is a special data type.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (200,false, 'class is used to allocate memory to a data type.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (200,false, 'none of the above.');


INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (201, 'What is the size of long variable?', 3);
INSERT into topics (id, TOPIC) values (201, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (201,false, '8 bit');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (201,false, '16 bit');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (201,false, '32 bit');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (201,true, '64 bit');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (202, 'What is the default value of float variable?', 3);
INSERT into topics (id, TOPIC) values (202, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (202,false, '0.0d');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (202,true, '0.0f');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (202,false, '0');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (202,false, 'not defined');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (203, 'What is an immutable object?', 3);
INSERT into topics (id, TOPIC) values (203, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (203,false, 'An immutable object can be changed once it is created.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (203,true, 'An immutable object cant be changed once it is created.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (203,false, 'An immutable object is an instance of an abstract class.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (203,false, 'None of the above');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (204, 'What is JRE?', 4);
INSERT into topics (id, TOPIC) values (204, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (204,false, 'JRE is a java based GUI application.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (204,false, 'JRE is an application development framework.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (204,true, 'JRE is an implementation of the Java Virtual Machine which executes Java programs.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (204,false, 'None of the above');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (205, 'Method Overriding is an example of?', 3);
INSERT into topics (id, TOPIC) values (205, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (205,false, 'Static Binding.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (205,true, 'Dynamic Binding.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (205,false, 'Both of the above.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (205,false, 'None of the above');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (206, 'What invokes a threads run() method?', 5);
INSERT into topics (id, TOPIC) values (206, 'JAVA');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (206,true, 'JVM invokes the threads run() method when the thread is initially executed.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (206,false, 'Main application running the thread.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (206,false, 'start() method of the thread class.');
INSERT INTO CHOICE (question_id, valid, LABEL) VALUES (206,false, 'None of the above');


INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (207, 'Deletion is faster in LinkedList than ArrayList?', 2);
INSERT into topics (id, TOPIC) values (207, 'JAVA');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (207, 'True');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (208, 'Which is a reserved word in the Java programming language?', 2);
INSERT into topics (id, TOPIC) values (208, 'JAVA');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (208, 'Native');

INSERT INTO QUESTION (id, QUESTION, DIFFICULTY) VALUES (209, 'What is the numerical range of a char?', 3);
INSERT into topics (id, TOPIC) values (209, 'JAVA');
INSERT INTO ANSWERS (question_id, ANSWER_TEXT) VALUES (209, '0 to 65535');